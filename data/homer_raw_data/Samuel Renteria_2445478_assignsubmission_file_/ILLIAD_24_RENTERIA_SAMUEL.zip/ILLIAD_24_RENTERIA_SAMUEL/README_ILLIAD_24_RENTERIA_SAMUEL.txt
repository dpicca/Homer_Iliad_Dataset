Description de l'utilisation des métadonnées dans label studio.

1. Les métadonnées sur un label speech se réfèrent à l'Id contenant leur speaker

2. Les métadonnées d'un speaker contiennent soit:
	
	1.Si le speaker se réfère à une Id speech, tous les speech de ce speaker donné.
	
	2.Si le speaker se réfère à une Id speaker, la première occurence de ce speaker.